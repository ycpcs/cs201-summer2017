package edu.ycp.cs201.fileio;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class LongestLine {
	public static void main(String[] args) throws IOException {
		Scanner keyboard = new Scanner(System.in);
		System.out.print("What file? ");
		String fileName = keyboard.nextLine();
		
		FileReader r = new FileReader(fileName);
		BufferedReader br = new BufferedReader(r);
		
		int longest = 0;
		while (true) {
			String line = br.readLine();
			if (line == null) {
				break;
			}
			if (line.length() > longest) {
				longest = line.length();
			}
		}
		
		br.close(); // Note: not guaranteed to be called!
		
		System.out.println("Longest line is " + longest + " characters");
	}
}
