package edu.ycp.cs201.fileio;

import java.io.FileWriter;
import java.io.IOException;

public class WriteFile {
	public static void main(String[] args) throws IOException {
		FileWriter fw = new FileWriter("output.txt");
		
		fw.write("This is some data! Yay!\n");
		
		fw.close();
		
		System.out.println("Wrote the data!");
	}
}
