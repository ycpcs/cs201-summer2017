package edu.ycp.cs201.fileio;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class CountVowels {
	public static void main(String[] args) throws IOException {
		Scanner keyboard = new Scanner(System.in);
		System.out.print("What file? ");
		String fileName = keyboard.nextLine();
		
		FileReader r = new FileReader(fileName);
		int count = 0;
		while (true) {
			int c = r.read();
			if (c < 0) {
				break;
			}
			c = Character.toLowerCase(c);
			if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
				count++;
			}
		}
		r.close(); // Note: not guaranteed to be called!
		
		System.out.println("There were " + count + " vowels");
	}
}
