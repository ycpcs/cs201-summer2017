package edu.ycp.cs201.point;

public class Point {
	// fields
	private double x;
	private double y;
	
	// constructors
	
	public Point() {
	}
	
	public Point(double xVal, double yVal) {
		x = xVal;
		y = yVal;
	}
	
	// methods
	public double getX() {
		return x;
	}
	
	public double getY() {
		return y;
	}
	
	public void setX(double xVal) {
		x = xVal;
	}
	
	public void setY(double yVal) {
		y = yVal;
	}
	
	public double distance(Point other) {
		double xdiff = this.x - other.x;
		double ydiff = this.y - other.y;
		return Math.sqrt(xdiff*xdiff + ydiff*ydiff);
	}
}
