package edu.ycp.cs201.point;

public class Main {
	public static void main(String[] args) {
		Point p1 = new Point(3.0, 4.0);
		Point p2;
		
		p2 = p1;
		
		p1.setX(6.0);
		
		System.out.println(p2.getX());
		
		int[] a1 = new int[2];
		int[] a2;
		
		a1[0] = 3;
		
		a2 = a1;
		
		a1[0] = 7;
		System.out.println(a2[0]);
		
		System.out.println(a2.length);
		
		int[][] board = new int[3][3];
		
	}
}
