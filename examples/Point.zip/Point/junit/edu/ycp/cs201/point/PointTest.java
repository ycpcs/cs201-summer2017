package edu.ycp.cs201.point;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class PointTest {
	private static final double DELTA = 0.00001;
	// test fixture
	private Point p;
	private Point origin;
	private Point p1;
	private Point p2;
	
	@Before
	public void setUp() {
		p = new Point();
		origin = new Point(0.0, 0.0);
		p1 = new Point(3.0, 4.0);
		p2 = new Point(5.0, 12.0);
	}
	
	// test methods
	@Test
	public void testGetX() throws Exception {
		assertEquals(0.0, p.getX(), DELTA);
		assertEquals(0.0, origin.getX(), DELTA);
		assertEquals(3.0, p1.getX(), DELTA);
		assertEquals(5.0, p2.getX(), DELTA);
	}
	
	@Test
	public void testSetX() throws Exception {
		p.setX(4.5);
		assertEquals(4.5, p.getX(), DELTA);
	}
	
	@Test
	public void testDistance() throws Exception {
		assertEquals(5.0, origin.distance(p1), DELTA);
		assertEquals(13.0, origin.distance(p2), DELTA);
	}
}
