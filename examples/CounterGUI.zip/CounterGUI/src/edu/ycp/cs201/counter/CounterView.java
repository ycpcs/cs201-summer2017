package edu.ycp.cs201.counter;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class CounterView extends JPanel {
	private Counter model;
	private CounterController controller;
	
	public CounterView() {
		setPreferredSize(new Dimension(200, 200));
		setBackground(Color.BLACK);
		
		addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				handleMouseClick(e);
			}
		});
	}
	
	protected void handleMouseClick(MouseEvent e) {
		// Goal:
		// left click -> increment the counter
		// right click -> decrement the counter
		if (e.getButton() == 1) {
			controller.increment();
		} else if (e.getButton() == 3) {
			controller.decrement();
		}
		
		repaint();
	}

	public void setModel(Counter model) {
		this.model = model;
	}
	
	public void setController(CounterController controller) {
		this.controller = controller;
	}
	
	@Override
	protected void paintComponent(Graphics g) {
		// Draw background
		super.paintComponent(g);
		
		// Get data from the model, render it
		Font f  = new Font("Dialog", Font.BOLD, 48);
		g.setFont(f);
		g.setColor(Color.LIGHT_GRAY);
		g.drawString(String.valueOf(model.getCount()), 10, 100);
	}
	
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				JFrame frame = new JFrame("Counter GUI");
				
				Counter model = new Counter();
				CounterView view = new CounterView();
				CounterController controller = new CounterController();
				
				view.setModel(model);
				view.setController(controller);
				
				controller.setModel(model);
				
				frame.setContentPane(view);
				frame.pack();
				
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				
				frame.setVisible(true);
			}
		});
	}
}
