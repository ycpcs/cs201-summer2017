package edu.ycp.cs201.counter;

public class CounterController {
	private Counter model;
	
	public CounterController() {
		
	}
	
	public void setModel(Counter model) {
		this.model = model;
	}
	
	// Methods which perform operations on the model object
	// (logic)
	public void increment() {
		int count = model.getCount();
		model.setCount(count + 1);
	}
	
	public void decrement() {
		int count = model.getCount();
		if (count > 0) {
			model.setCount(count - 1);
		}
	}
}
