package edu.ycp.cs201.exam1;

public class Histogram {
	private int[] buckets;

	public Histogram(int numBuckets) {
		buckets = new int[numBuckets];
	}

	public int get(int i) {
		return buckets[i];
	}

	public void increment(int i) {
		buckets[i]++;
	}
}
