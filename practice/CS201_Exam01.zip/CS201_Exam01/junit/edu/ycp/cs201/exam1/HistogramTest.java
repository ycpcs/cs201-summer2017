package edu.ycp.cs201.exam1;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class HistogramTest {
	private Histogram small;
	private Histogram large;
	
	@Before
	public void setUp() {
		small = new Histogram(10);
		large = new Histogram(50);
	}
	
	@Test
	public void testInitialBucketCountIsZero() throws Exception {
		assertEquals(0, small.get(0));
		assertEquals(0, small.get(1));
		assertEquals(0, small.get(2));
		assertEquals(0, small.get(3));
		assertEquals(0, small.get(4));
		assertEquals(0, small.get(5));
		assertEquals(0, small.get(6));
		assertEquals(0, small.get(7));
		assertEquals(0, small.get(8));
		assertEquals(0, small.get(9));
	}
	
	@Test
	public void testIncrement() throws Exception {
		assertEquals(0, small.get(0));
		small.increment(0);
		small.increment(0);
		small.increment(0);
		assertEquals(3, small.get(0));
		
		assertEquals(0, small.get(7));
		small.increment(7);
		small.increment(7);
		small.increment(7);
		small.increment(7);
		small.increment(7);
		small.increment(7);
		small.increment(7);
		small.increment(7);
		assertEquals(8, small.get(7));
	}
	
	@Test
	public void testIncrementLarge() throws Exception {
		// Set each bucket's count equal to its bucket number
		// by incrementing the appropriate number of times
		for (int i = 0; i < 50; i++) {
			for (int j = 0; j < i; j++) {
				large.increment(i);
			}
		}
		
		for (int i = 0; i < 50; i++) {
			assertEquals(i, large.get(i));
		}
	}
}
