package edu.ycp.cs201.exam1;

public class Histogram {
	// TODO: add fields and methods as necessary
}
