package edu.ycp.cs201.exam02;

import java.util.ArrayList;

public class Exam2 {
	public static<E extends Comparable<E>> int countBetween(ArrayList<E> list, E min, E max) {
		int count = 0;
		for (E val : list) {
			if (val.compareTo(min) >= 0 && val.compareTo(max) <= 0) {
				count++;
			}
		}
		return count;
	}
}
