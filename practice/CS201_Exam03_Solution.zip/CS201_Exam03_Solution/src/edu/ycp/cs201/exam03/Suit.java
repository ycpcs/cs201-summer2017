package edu.ycp.cs201.exam03;

public enum Suit {
	CLUBS("♣"),
	DIAMONDS("♦"),
	HEARTS("♥"),
	SPADES("♠");
	
	private String symbol;
	
	private Suit(String symbol) {
		this.symbol = symbol;
	}
	
	@Override
	public String toString() {
		return symbol;
	}
}
