package edu.ycp.cs201.exam03;

public class Q10 {
	// IMPORTANT: your implementation must be recursive.
	// Do not use a loop.
	public static int countOccurrences(String s, char c) {
		if (s.length() == 0) {
			return 0;
		}
		int x = 0;
		if (s.charAt(0) == c) {
			x = 1;
		}
		return x + countOccurrences(s.substring(1), c);
	}
}
