package edu.ycp.cs201.exam03;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class Q11 {
	public static Map<Suit, Integer> countSuits(List<Card> hand) {
		Map<Suit, Integer> result = new HashMap<Suit, Integer>();
		for (Card c : hand) {
			Suit s = c.getSuit();
			if (!result.containsKey(s)) {
				result.put(s, 0);
			}
			result.put(s, result.get(s) + 1);
		}
		return result;
	}
}
