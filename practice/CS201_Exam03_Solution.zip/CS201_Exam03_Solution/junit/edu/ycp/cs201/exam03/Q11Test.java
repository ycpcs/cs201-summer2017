package edu.ycp.cs201.exam03;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

public class Q11Test {
	private List<Card> hand1;
	private List<Card> hand2;
	
	@Before
	public void setUp() {
		hand1 = Arrays.asList(
				new Card(Rank.FIVE, Suit.DIAMONDS),
				new Card(Rank.NINE, Suit.DIAMONDS),
				new Card(Rank.JACK, Suit.CLUBS),
				new Card(Rank.TEN, Suit.CLUBS),
				new Card(Rank.EIGHT, Suit.DIAMONDS),
				new Card(Rank.FIVE, Suit.CLUBS),
				new Card(Rank.KING, Suit.HEARTS),
				new Card(Rank.THREE, Suit.DIAMONDS),
				new Card(Rank.FOUR, Suit.SPADES),
				new Card(Rank.ACE, Suit.DIAMONDS)
		);
		
		hand2 = Arrays.asList(
				new Card(Rank.JACK, Suit.DIAMONDS),
				new Card(Rank.TEN, Suit.SPADES),
				new Card(Rank.NINE, Suit.DIAMONDS),
				new Card(Rank.SEVEN, Suit.HEARTS),
				new Card(Rank.EIGHT, Suit.DIAMONDS),
				new Card(Rank.ACE, Suit.DIAMONDS),
				new Card(Rank.THREE, Suit.DIAMONDS),
				new Card(Rank.ACE, Suit.CLUBS),
				new Card(Rank.SIX, Suit.HEARTS),
				new Card(Rank.QUEEN, Suit.DIAMONDS)
		);
	}
	
	@Test
	public void testCountSuitsHand1() throws Exception {
		Map<Suit, Integer> counts = Q11.countSuits(hand1);
		assertEquals((Integer)3, counts.get(Suit.CLUBS));
		assertEquals((Integer)5, counts.get(Suit.DIAMONDS));
		assertEquals((Integer)1, counts.get(Suit.HEARTS));
		assertEquals((Integer)1, counts.get(Suit.SPADES));
	}
	
	@Test
	public void testCountSuitsHand2() throws Exception {
		Map<Suit, Integer> counts = Q11.countSuits(hand2);
		assertEquals((Integer)1, counts.get(Suit.CLUBS));
		assertEquals((Integer)6, counts.get(Suit.DIAMONDS));
		assertEquals((Integer)2, counts.get(Suit.HEARTS));
		assertEquals((Integer)1, counts.get(Suit.SPADES));
	}
}
