package edu.ycp.cs201.exam03;

import static org.junit.Assert.*;

import org.junit.Test;

public class Q10Test {
	@Test
	public void testCountOccurrences() throws Exception {
		assertEquals(4, Q10.countOccurrences("A smell of petroleum prevails throughout", 'e'));
		assertEquals(5, Q10.countOccurrences("A smell of petroleum prevails throughout", ' '));
		assertEquals(3, Q10.countOccurrences("A smell of petroleum prevails throughout", 't'));
		assertEquals(0, Q10.countOccurrences("A smell of petroleum prevails throughout", 'x'));
		
		assertEquals(2, Q10.countOccurrences("All your base are belong to us", 'r'));
		assertEquals(0, Q10.countOccurrences("All your base are belong to us", 'q'));
		assertEquals(1, Q10.countOccurrences("All your base are belong to us", 'A'));
		assertEquals(2, Q10.countOccurrences("All your base are belong to us", 'a'));
		assertEquals(2, Q10.countOccurrences("All your base are belong to us", 'b'));
		
		assertEquals(1, Q10.countOccurrences("a", 'a'));
		assertEquals(0, Q10.countOccurrences("", 'a'));
	}
}
