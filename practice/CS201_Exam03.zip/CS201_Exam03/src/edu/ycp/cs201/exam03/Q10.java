package edu.ycp.cs201.exam03;

public class Q10 {
	// IMPORTANT: your implementation must be recursive.
	// Do not use a loop.
	public static int countOccurrences(String s, char c) {
		throw new UnsupportedOperationException("TODO - implement");
	}
}
