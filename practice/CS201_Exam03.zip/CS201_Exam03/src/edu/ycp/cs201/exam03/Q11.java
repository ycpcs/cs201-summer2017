package edu.ycp.cs201.exam03;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class Q11 {
	public static Map<Suit, Integer> countSuits(List<Card> hand) {
		throw new UnsupportedOperationException("TODO - implement");
	}
}
