package edu.ycp.cs201.exam02;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;

public class Exam2Test {
	private ArrayList<Integer> numList;
	private ArrayList<Character> charList;
	
	@Before
	public void setUp() {
		numList = new ArrayList<Integer>();
		numList.addAll(Arrays.asList(7, 5, 14, 11, 5, 1, 8, 15, 3, 9));
		charList = new ArrayList<Character>();
		charList.addAll(Arrays.asList('T', 'S', 'N', 'L', 'V', 'D', 'Y', 'J'));
	}
	
	@Test
	public void testCountBetweenInNumList() throws Exception {
		assertEquals(5, Exam2.countBetween(numList, 2, 8));
		assertEquals(2, Exam2.countBetween(numList, 13, 19));
	}
	
	@Test
	public void testCountBetweenInCharList() throws Exception {
		assertEquals(4, Exam2.countBetween(charList, 'C', 'R'));
		assertEquals(2, Exam2.countBetween(charList, 'A', 'J'));
	}
}
