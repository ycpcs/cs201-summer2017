package edu.ycp.cs201.exam02;

import java.util.ArrayList;

public class Exam2 {
	public static<E extends Comparable<E>> int countBetween(ArrayList<E> list, E min, E max) {
		throw new UnsupportedOperationException("TODO: implement");
	}
}
